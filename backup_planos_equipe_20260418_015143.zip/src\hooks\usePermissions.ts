'use client';

import { AppModule, ModuleAccess, PLAN_LIMITS, PlanType, TeamMember, DEFAULT_MEMBER_PERMISSIONS, Subscription, AppUser } from '@/types';

interface UsePermissionsProps {
  currentUser: AppUser | null;
}

export function usePermissions({ currentUser }: UsePermissionsProps) {
  const isOwner = currentUser?.role === 'OWNER';
  const isMember = currentUser?.role === 'MEMBER';

  const canView = (module: AppModule): boolean => {
    if (isOwner) return true;
    const access = currentUser?.permissions?.[module];
    return access === 'VIEW' || access === 'EDIT';
  };

  const canEdit = (module: AppModule): boolean => {
    if (isOwner) return true;
    return currentUser?.permissions?.[module] === 'EDIT';
  };

  const canAddMember = (): boolean => {
    if (!isOwner || !currentUser?.subscription) return false;
    const limit = PLAN_LIMITS[currentUser.subscription.plan as PlanType].maxMembers;
    const current = currentUser.teamMembers?.length ?? 0;
    return current < limit;
  };

  const getRemainingSlots = (): number => {
    if (!isOwner || !currentUser?.subscription) return 0;
    const limit = PLAN_LIMITS[currentUser.subscription.plan as PlanType].maxMembers;
    const current = currentUser.teamMembers?.length ?? 0;
    return Math.max(0, limit - current);
  };

  const getPlanLabel = (): string => {
    if (!currentUser?.subscription) return 'Free';
    return PLAN_LIMITS[currentUser.subscription.plan as PlanType].label;
  };

  const canAccessModule = (module: AppModule, requiredAccess: ModuleAccess): boolean => {
    if (isOwner) return true;
    const access = currentUser?.permissions?.[module];
    if (requiredAccess === 'VIEW') return access === 'VIEW' || access === 'EDIT';
    if (requiredAccess === 'EDIT') return access === 'EDIT';
    return access === 'NONE';
  };

  return {
    isOwner,
    isMember,
    canView,
    canEdit,
    canAddMember,
    getRemainingSlots,
    getPlanLabel,
    canAccessModule,
  };
}

export function saveTeamMembers(ownerId: string, members: TeamMember[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(`owner_${ownerId}_team`, JSON.stringify(members));
}

export function loadTeamMembers(ownerId: string): TeamMember[] {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(`owner_${ownerId}_team`);
  if (!stored) return [];
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
}

export function saveSubscription(ownerId: string, subscription: Subscription): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(`owner_${ownerId}_subscription`, JSON.stringify(subscription));
}

export function loadSubscription(ownerId: string): Subscription | null {
  if (typeof window === 'undefined') return null;
  const stored = localStorage.getItem(`owner_${ownerId}_subscription`);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}

export function saveMemberPermissions(memberId: string, permissions: Record<AppModule, ModuleAccess>): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(`member_${memberId}_permissions`, JSON.stringify(permissions));
}

export function loadMemberPermissions(memberId: string): Record<AppModule, ModuleAccess> | null {
  if (typeof window === 'undefined') return null;
  const stored = localStorage.getItem(`member_${memberId}_permissions`);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}

export function initializeSubscription(ownerId: string, plan: PlanType = 'PRO_MAX'): Subscription {
  const now = new Date().toISOString();
  const trialEnd = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
  
  const subscription: Subscription = {
    plan,
    trialStartDate: now,
    trialEndDate: trialEnd,
    isTrialActive: true,
    isBlocked: false,
    maxMembers: PLAN_LIMITS[plan].maxMembers,
  };
  
  saveSubscription(ownerId, subscription);
  return subscription;
}

export function createTeamMember(name: string, email: string): TeamMember {
  return {
    id: `member_${Date.now()}`,
    name,
    email,
    role: 'MEMBER',
    addedAt: new Date().toISOString(),
    isActive: true,
    permissions: { ...DEFAULT_MEMBER_PERMISSIONS },
  };
}