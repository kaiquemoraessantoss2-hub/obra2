'use client';

import React from 'react';
import { Plus, Settings, Trash2, UserCheck, UserX, Crown } from 'lucide-react';
import { TeamMember, PLAN_LIMITS, AppModule, ModuleAccess, PlanType, ALL_MODULES, MODULE_LABELS } from '@/types';
import { cn } from '@/lib/utils';

interface PlanBadgeProps {
  plan: PlanType;
  onClick?: () => void;
}

export default function PlanBadge({ plan, onClick }: PlanBadgeProps) {
  const { maxMembers, label } = PLAN_LIMITS[plan];

  const getStyles = () => {
    switch (plan) {
      case 'BASIC':
        return 'bg-slate-700/50 text-slate-300 border-slate-600/30';
      case 'GOLD':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'PRO_MAX':
        return 'bg-gradient-to-r from-violet-600/30 to-blue-600/30 text-blue-300 border-violet-500/30';
      default:
        return 'bg-slate-700/50 text-slate-300 border-slate-600/30';
    }
  };

  const getIcon = () => {
    switch (plan) {
      case 'GOLD':
        return ' ✨';
      case 'PRO_MAX':
        return ' 💎';
      default:
        return '';
    }
  };

  return (
    <button
      onClick={onClick}
      className={cn(
        "px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest border transition-all hover:scale-105",
        getStyles(),
        onClick && "cursor-pointer"
      )}
    >
      {label}{getIcon()}
    </button>
  );
}