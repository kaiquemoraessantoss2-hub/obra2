'use client';

import React, { useState } from 'react';
import { Plus, Settings, Trash2, UserCheck, UserX, Crown, Mail } from 'lucide-react';
import { TeamMember, PLAN_LIMITS, PlanType, Subscription, AppModule, ModuleAccess, ALL_MODULES, MODULE_LABELS } from '@/types';
import { cn } from '@/lib/utils';
import PlanBadge from './PlanBadge';
import InviteMemberModal from './InviteMemberModal';
import MemberPermissionsModal from './MemberPermissionsModal';

interface TeamManagementPageProps {
  subscription: Subscription | null;
  teamMembers: TeamMember[];
  onAddMember: (name: string, email: string, permissions: Record<AppModule, ModuleAccess>) => void;
  onUpdateMember: (memberId: string, permissions: Record<AppModule, ModuleAccess>) => void;
  onRemoveMember: (memberId: string) => void;
  isOwner: boolean;
}

export default function TeamManagementPage({
  subscription,
  teamMembers,
  onAddMember,
  onUpdateMember,
  onRemoveMember,
  isOwner,
}: TeamManagementPageProps) {
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  const plan = subscription?.plan || 'BASIC';
  const { maxMembers } = PLAN_LIMITS[plan];
  const currentCount = teamMembers?.length || 0;
  const canAdd = isOwner && currentCount < maxMembers;

  const openPermissions = (member: TeamMember) => {
    setSelectedMember(member);
    setShowPermissionsModal(true);
  };

  const handleSavePermissions = (memberId: string, permissions: Record<AppModule, ModuleAccess>) => {
    onUpdateMember(memberId, permissions);
    setShowPermissionsModal(false);
    setSelectedMember(null);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="glass-card p-8 rounded-[40px]">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-white">Minha Equipe</h2>
            <p className="text-sm text-slate-500 mt-1">
              Gerencie os membros que têm acesso à obra
            </p>
          </div>
          <div className="flex items-center gap-4">
            <PlanBadge 
              plan={plan} 
              onClick={() => {}}
            />
            <div className="text-right">
              <p className="text-2xl font-black text-white">
                {currentCount}/{maxMembers}
              </p>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest">
                membros
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Botão adicionar */}
      <button
        onClick={() => setShowInviteModal(true)}
        disabled={!canAdd}
        className={cn(
          "w-full py-4 rounded-2xl border-2 border-dashed transition-all flex items-center justify-center gap-2",
          canAdd 
            ? "border-white/10 text-slate-500 hover:border-blue-500/50 hover:text-blue-400" 
            : "border-white/5 text-slate-600 cursor-not-allowed opacity-50"
        )}
      >
        <Plus size={20} />
        {canAdd ? 'Convidar Membro' : `Limite do plano ${PLAN_LIMITS[plan].label} atingido (${currentCount}/${maxMembers})`}
      </button>

      {/* Lista de membros */}
      <div className="space-y-3">
        {(!teamMembers || teamMembers.length === 0) && (
          <div className="glass-card p-12 rounded-[40px] text-center">
            <p className="text-slate-500">Nenhum membro na equipe ainda.</p>
            <p className="text-sm text-slate-600 mt-1">
              Convide membros para collaborarem nesta obra.
            </p>
          </div>
        )}

        {teamMembers?.map(member => (
          <div 
            key={member.id}
            className="glass-card p-6 rounded-2xl flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center font-black text-lg",
                member.role === 'OWNER' ? "bg-amber-500/20 text-amber-400" : "bg-blue-600/20 text-blue-400"
              )}>
                {member.name[0].toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-white">{member.name}</span>
                  {member.role === 'OWNER' && <Crown size={14} className="text-amber-400" />}
                  {member.isActive ? (
                    <span className="px-2 py-0.5 rounded-full text-[8px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      ATIVO
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[8px] bg-slate-700/50 text-slate-400 border border-slate-600/30">
                      INATIVO
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <Mail size={12} />
                  {member.email}
                </div>
                <div className="flex gap-1 mt-1">
                  {ALL_MODULES.filter(m => member.permissions[m] && member.permissions[m] !== 'NONE').map(module => (
                    <span 
                      key={module}
                      className="px-2 py-0.5 rounded text-[8px] bg-blue-600/10 text-blue-400 border border-blue-500/20"
                    >
                      {MODULE_LABELS[module]}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {isOwner && member.role !== 'OWNER' && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openPermissions(member)}
                  className="p-2 text-slate-500 hover:text-blue-400 hover:bg-blue-600/10 rounded-xl transition-all"
                >
                  <Settings size={18} />
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Remover ${member.name} da equipe?`)) {
                      onRemoveMember(member.id);
                    }
                  }}
                  className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-600/10 rounded-xl transition-all"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Modais */}
      <InviteMemberModal
        isOpen={showInviteModal}
        onClose={() => setShowInviteModal(false)}
        onInvite={onAddMember}
        canAdd={canAdd}
        maxMembers={maxMembers}
        currentMembers={currentCount}
        isOwner={isOwner}
      />

      <MemberPermissionsModal
        isOpen={showPermissionsModal}
        member={selectedMember}
        onClose={() => {
          setShowPermissionsModal(false);
          setSelectedMember(null);
        }}
        onSave={handleSavePermissions}
        isOwner={isOwner}
      />
    </div>
  );
}