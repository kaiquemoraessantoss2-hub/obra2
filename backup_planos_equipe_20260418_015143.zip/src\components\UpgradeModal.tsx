'use client';

import React from 'react';
import { X, Rocket, Crown, Star, Check } from 'lucide-react';
import { PLAN_LIMITS, PlanType } from '@/types';
import { cn } from '@/lib/utils';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: PlanType;
}

export default function UpgradeModal({ isOpen, onClose, currentPlan }: UpgradeModalProps) {
  if (!isOpen) return null;

  const handleWhatsApp = (plan: PlanType) => {
    const message = `Olá! Quero fazer upgrade para o plano ${PLAN_LIMITS[plan].label}. Meu cadastro é: [seu email]`;
    const url = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative glass-card p-8 rounded-[40px] max-w-4xl w-full">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Rocket size={28} className="text-blue-400" />
            <div>
              <h2 className="text-2xl font-black text-white">Faça upgrade do seu plano</h2>
              <p className="text-sm text-slate-500">Escolha o melhor plano para sua obra</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* BASIC */}
          <div className={cn(
            "glass-card p-6 rounded-3xl border-2",
            currentPlan === 'BASIC' ? "border-blue-500/50" : "border-white/10"
          )}>
            <div className="text-center mb-6">
              <h3 className="text-xl font-black text-white">Basic</h3>
              <p className="text-3xl font-black text-slate-400 mt-2">Grátis</p>
            </div>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-sm text-slate-400">
                <Check size={16} className="text-slate-500" /> 1 usuário
              </li>
              <li className="flex items-center gap-2 text-sm text-slate-400">
                <Check size={16} className="text-slate-500" /> Todas funcionalidades
              </li>
              <li className="flex items-center gap-2 text-sm text-slate-600">
                <span className="text-slate-600" /> Sem equipe
              </li>
            </ul>
            <button
              disabled={currentPlan !== 'BASIC'}
              className={cn(
                "w-full py-3 rounded-xl font-medium",
                currentPlan === 'BASIC' 
                  ? "bg-slate-700 text-slate-400 cursor-default"
                  : "bg-blue-600 hover:bg-blue-500 text-white"
              )}
            >
              {currentPlan === 'BASIC' ? 'Plano atual' : 'Selecionar'}
            </button>
          </div>

          {/* GOLD */}
          <div className={cn(
            "glass-card p-6 rounded-3xl border-2 relative",
            currentPlan === 'GOLD' ? "border-amber-500/50" : "border-amber-500/20",
            currentPlan === 'PRO_MAX' && "opacity-60"
          )}>
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-amber-500 rounded-full text-[10px] font-black text-black">
              ✨ Mais popular
            </div>
            <div className="text-center mb-6">
              <h3 className="text-xl font-black text-amber-400">Gold</h3>
              <p className="text-3xl font-black text-white mt-2">R$ 197<span className="text-sm text-slate-500">/mês</span></p>
            </div>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-sm text-white">
                <Check size={16} className="text-amber-400" /> 1 usuário + 3 membros
              </li>
              <li className="flex items-center gap-2 text-sm text-white">
                <Check size={16} className="text-amber-400" /> Controle de permissões
              </li>
              <li className="flex items-center gap-2 text-sm text-white">
                <Check size={16} className="text-amber-400" /> Todas funcionalidades
              </li>
            </ul>
            <button
              onClick={() => handleWhatsApp('GOLD')}
              disabled={currentPlan === 'GOLD' || currentPlan === 'PRO_MAX'}
              className={cn(
                "w-full py-3 rounded-xl font-medium",
                currentPlan === 'GOLD' 
                  ? "bg-slate-700 text-slate-400 cursor-default"
                  : currentPlan === 'PRO_MAX'
                    ? "bg-slate-700 text-slate-500 opacity-50 cursor-not-allowed"
                    : "bg-amber-500 hover:bg-amber-400 text-black"
              )}
            >
              {currentPlan === 'GOLD' ? 'Plano atual' : currentPlan === 'PRO_MAX' ? 'Já incluso' : 'Contratar'}
            </button>
          </div>

          {/* PRO MAX */}
          <div className={cn(
            "glass-card p-6 rounded-3xl border-2 relative",
            currentPlan === 'PRO_MAX' ? "border-violet-500/50" : "border-violet-500/20"
          )}>
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-gradient-to-r from-violet-600 to-blue-600 rounded-full text-[10px] font-black text-white">
              💎 Premium
            </div>
            <div className="text-center mb-6">
              <h3 className="text-xl font-black text-blue-400">Pro Max</h3>
              <p className="text-3xl font-black text-white mt-2">R$ 297<span className="text-sm text-slate-500">/mês</span></p>
            </div>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-sm text-white">
                <Check size={16} className="text-blue-400" /> 1 usuário + 5 membros
              </li>
              <li className="flex items-center gap-2 text-sm text-white">
                <Check size={16} className="text-blue-400" /> Controle total
              </li>
              <li className="flex items-center gap-2 text-sm text-white">
                <Check size={16} className="text-blue-400" /> Relatórios avançados
              </li>
              <li className="flex items-center gap-2 text-sm text-slate-500">
                <Check size={16} className="text-blue-400" /> Exportação completa
              </li>
            </ul>
            <button
              onClick={() => handleWhatsApp('PRO_MAX')}
              disabled={currentPlan === 'PRO_MAX'}
              className={cn(
                "w-full py-3 rounded-xl font-medium",
                currentPlan === 'PRO_MAX' 
                  ? "bg-violet-600 text-white"
                  : "bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white"
              )}
            >
              {currentPlan === 'PRO_MAX' ? 'Plano atual' : 'Contratar'}
            </button>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-slate-500 mb-4">
            Precisa de ajuda para escolher?
          </p>
          <button
            onClick={() => handleWhatsApp('PRO_MAX')}
            className="px-6 py-2.5 bg-white/5 hover:bg-white/10 text-slate-400 rounded-xl text-sm font-medium"
          >
            💬 Falar no WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}