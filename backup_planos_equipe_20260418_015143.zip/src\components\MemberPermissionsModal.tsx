'use client';

import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { AppModule, ModuleAccess, TeamMember, ALL_MODULES, MODULE_LABELS } from '@/types';
import { cn } from '@/lib/utils';

interface MemberPermissionsModalProps {
  isOpen: boolean;
  member: TeamMember | null;
  onClose: () => void;
  onSave: (memberId: string, permissions: Record<AppModule, ModuleAccess>) => void;
  isOwner: boolean;
}

export default function MemberPermissionsModal({ 
  isOpen, 
  member, 
  onClose, 
  onSave,
  isOwner 
}: MemberPermissionsModalProps) {
  const defaultPermissions: Record<AppModule, ModuleAccess> = {
    DASHBOARD: 'VIEW',
    CRONOGRAMA: 'VIEW',
    PAVIMENTOS: 'NONE',
    MEDICAO: 'NONE',
    DOCUMENTOS: 'NONE',
    EQUIPE: 'NONE',
    CONFIGURACOES: 'NONE',
  };

  const [permissions, setPermissions] = useState<Record<AppModule, ModuleAccess>>(
    member?.permissions || defaultPermissions
  );

  if (!isOpen || !member) return null;

  const handleChange = (module: AppModule, access: ModuleAccess) => {
    setPermissions(prev => ({ ...prev, [module]: access }));
  };

  const isBlockedModule = (module: AppModule): boolean => {
    return module === 'EQUIPE' || module === 'CONFIGURACOES';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative glass-card p-8 rounded-[40px] max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-black text-white">Permissões do Membro</h2>
            <p className="text-sm text-slate-500">{member.name}</p>
            <p className="text-xs text-slate-600">{member.email}</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="space-y-2 mb-8">
          <div className="grid grid-cols-4 gap-4 text-[10px] font-black text-slate-600 uppercase tracking-widest pb-2 border-b border-white/5">
            <div>Módulo</div>
            <div className="text-center">Sem acesso</div>
            <div className="text-center">Visualizar</div>
            <div className="text-center">Editar</div>
          </div>

          {ALL_MODULES.filter(m => m !== 'DOCUMENTOS').map(module => {
            const isBlocked = isBlockedModule(module);
            const current = permissions[module] || 'NONE';

            return (
              <div 
                key={module} 
                className={cn(
                  "grid grid-cols-4 gap-4 items-center py-3 border-b border-white/5",
                  isBlocked && "opacity-40"
                )}
              >
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-sm font-medium",
                    current !== 'NONE' ? "text-white" : "text-slate-500"
                  )}>
                    {MODULE_LABELS[module]}
                  </span>
                  {isBlocked && (
                    <span className="text-[10px] text-slate-600">🔒</span>
                  )}
                </div>

                <div className="flex justify-center">
                  <button
                    disabled={isBlocked}
                    onClick={() => handleChange(module, 'NONE')}
                    className={cn(
                      "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                      current === 'NONE' ? "border-blue-500 bg-blue-500" : "border-white/20",
                      !isBlocked && "cursor-pointer hover:border-blue-400",
                      isBlocked && "cursor-not-allowed opacity-30"
                    )}
                  >
                    {current === 'NONE' && <Check size={12} className="text-white" />}
                  </button>
                </div>

                <div className="flex justify-center">
                  <button
                    disabled={isBlocked}
                    onClick={() => handleChange(module, 'VIEW')}
                    className={cn(
                      "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                      current === 'VIEW' ? "border-blue-500 bg-blue-500" : "border-white/20",
                      !isBlocked && "cursor-pointer hover:border-blue-400",
                      isBlocked && "cursor-not-allowed opacity-30"
                    )}
                  >
                    {current === 'VIEW' && <Check size={12} className="text-white" />}
                  </button>
                </div>

                <div className="flex justify-center">
                  <button
                    disabled={isBlocked}
                    onClick={() => handleChange(module, 'EDIT')}
                    className={cn(
                      "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                      current === 'EDIT' ? "border-blue-500 bg-blue-500" : "border-white/20",
                      !isBlocked && "cursor-pointer hover:border-blue-400",
                      isBlocked && "cursor-not-allowed opacity-30"
                    )}
                  >
                    {current === 'EDIT' && <Check size={12} className="text-white" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 text-slate-500 hover:text-white text-sm font-medium"
          >
            Cancelar
          </button>
          <button 
            onClick={() => onSave(member.id, permissions)}
            disabled={!isOwner}
            className={cn(
              "px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-medium",
              !isOwner && "opacity-50 cursor-not-allowed"
            )}
          >
            Salvar Permissões
          </button>
        </div>
      </div>
    </div>
  );
}