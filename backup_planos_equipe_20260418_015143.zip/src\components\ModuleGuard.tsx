'use client';

import React from 'react';
import { AppModule, ModuleAccess } from '@/types';
import { Lock, Eye } from 'lucide-react';
import { usePermissions } from '@/hooks/usePermissions';
import { AppUser } from '@/types';

interface ModuleGuardProps {
  module: AppModule;
  access: 'VIEW' | 'EDIT';
  currentUser: AppUser | null;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export default function ModuleGuard({ 
  module, 
  access, 
  currentUser, 
  children,
  fallback 
}: ModuleGuardProps) {
  const { canAccessModule, isOwner } = usePermissions({ currentUser });

  const hasAccess = canAccessModule(module, access);

  if (hasAccess) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  return (
    <div className="glass-card p-12 rounded-[40px] border border-white/5 text-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center">
          <Lock size={32} className="text-slate-500" />
        </div>
        <div>
          <h3 className="text-lg font-black text-white mb-2">Acesso Bloqueado</h3>
          <p className="text-sm text-slate-500">
            Você não tem acesso a este módulo.
          </p>
          <p className="text-sm text-slate-500 mt-1">
            Fale com o responsável da obra para solicitar acesso.
          </p>
        </div>
        {!isOwner && (
          <div className="mt-4 px-4 py-2 bg-blue-600/10 rounded-xl text-blue-400 text-sm">
            <Eye size={14} className="inline mr-2" />
            Módulo: {module}
          </div>
        )}
      </div>
    </div>
  );
}