'use client';

import React, { useState } from 'react';
import { X, Plus, Mail, User } from 'lucide-react';
import { AppModule, ModuleAccess, DEFAULT_MEMBER_PERMISSIONS, ALL_MODULES, MODULE_LABELS } from '@/types';
import { cn } from '@/lib/utils';

interface InviteMemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInvite: (name: string, email: string, permissions: Record<AppModule, ModuleAccess>) => void;
  canAdd: boolean;
  maxMembers: number;
  currentMembers: number;
  isOwner: boolean;
}

export default function InviteMemberModal({ 
  isOpen, 
  onClose, 
  onInvite, 
  canAdd, 
  maxMembers,
  currentMembers,
  isOwner 
}: InviteMemberModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [permissions, setPermissions] = useState<Record<AppModule, ModuleAccess>>({ ...DEFAULT_MEMBER_PERMISSIONS } as any);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!name.trim() || !email.trim()) return;
    onInvite(name.trim(), email.trim(), permissions);
    setName('');
    setEmail('');
    setPermissions({ ...DEFAULT_MEMBER_PERMISSIONS });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative glass-card p-8 rounded-[40px] max-w-lg w-full">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-black text-white">Convidar Membro</h2>
            <p className="text-sm text-slate-500">
              {currentMembers}/{maxMembers} membros utilizados
            </p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-500 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {!canAdd ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">⚠️</span>
            </div>
            <h3 className="text-lg font-black text-white mb-2">Limite do plano atingido</h3>
            <p className="text-sm text-slate-500">
              Você atingiu o limite de {maxMembers} membros deste plano.
            </p>
            <p className="text-sm text-slate-500 mt-1">
              Faça upgrade para adicionar mais membros.
            </p>
          </div>
        ) : (
          <>
            <div className="space-y-4 mb-6">
              <div>
                <label className="text-[10px] font-black text-slate-600 uppercase block mb-2">
                  Nome do membro
                </label>
                <div className="relative">
                  <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white"
                    placeholder="João da Silva"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-600 uppercase block mb-2">
                  E-mail
                </label>
                <div className="relative">
                  <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white"
                    placeholder="joao@email.com"
                  />
                </div>
              </div>
            </div>

            <div className="mb-6">
              <label className="text-[10px] font-black text-slate-600 uppercase block mb-3">
                Permissões iniciais
              </label>
              <div className="grid grid-cols-2 gap-2">
                {ALL_MODULES.filter(m => m !== 'EQUIPE' && m !== 'CONFIGURACOES').map(module => (
                  <button
                    key={module}
                    onClick={() => setPermissions(prev => ({
                      ...prev,
                      [module]: prev[module] === 'VIEW' ? 'NONE' : 'VIEW'
                    }))}
                    className={cn(
                      "px-3 py-2 rounded-lg text-sm font-medium transition-all border",
                      permissions[module] === 'VIEW' 
                        ? "bg-blue-600/20 border-blue-500/30 text-blue-400" 
                        : "bg-white/5 border-white/10 text-slate-500"
                    )}
                  >
                    {MODULE_LABELS[module]}
                    {permissions[module] === 'VIEW' && ' ✓'}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={!name.trim() || !email.trim() || !isOwner}
              className={cn(
                "w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-medium transition-all",
                (!name.trim() || !email.trim() || !isOwner) && "opacity-50 cursor-not-allowed"
              )}
            >
              <Plus size={18} className="inline mr-2" />
              Enviar convite
            </button>
          </>
        )}
      </div>
    </div>
  );
}